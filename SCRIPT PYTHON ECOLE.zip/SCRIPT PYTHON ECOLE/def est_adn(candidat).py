#Auteur:François Roland
def est_adn(candidat):
    if len(candidat) > 0:
        for c in candidat:
            if not (c in "ACGT"):
                return False
        return True
    else:
        return False