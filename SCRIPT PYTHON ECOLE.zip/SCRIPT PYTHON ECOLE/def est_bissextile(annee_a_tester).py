 #Auteur:François Roland
 
# L'année n’est bissextile que dans l’un des deux cas suivants :
# si l'année est divisible par 4 et non divisible par 100 ;
# si l'année est divisible par 400
# (« divisible » signifie que la division donne un nombre entier, sans reste).
def est_bissextile(annee_a_tester):
    return (annee_a_tester % 4 == 0 and annee_a_tester % 100 != 0) or (annee_a_tester % 400 == 0)
annee = int(input("Quelle année voulez-vous tester ? "))
if est_bissextile(annee):
    print("L'année est bissextile")
else:
    print("L'année n'est pas bissextile")